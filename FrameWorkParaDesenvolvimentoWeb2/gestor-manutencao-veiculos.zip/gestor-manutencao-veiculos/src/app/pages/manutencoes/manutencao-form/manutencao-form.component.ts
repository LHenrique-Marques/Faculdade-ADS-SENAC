import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ManutencaoService } from '../../../services/manutencao.service';
import { Manutencao } from '../../../models/manutencao.model';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';


@Component({
  selector: 'app-manutencao-form',
  standalone: true,
  imports: [
  CommonModule,
  ReactiveFormsModule,
  RouterModule,
  MatFormFieldModule,
  MatInputModule,
  MatButtonModule,
  MatCardModule
]
,
  templateUrl: './manutencao-form.component.html',
  styleUrl:'./manutencao-form.component.css'
})
export class ManutencaoFormComponent {
  form: FormGroup;
  isEdit = false;
  manutencaoId!: number;
  veiculoId!: string; 

  constructor(
    public fb: FormBuilder,
    public manutencaoService: ManutencaoService,
    public route: ActivatedRoute,
    public router: Router
  ) {
    this.form = this.fb.group({
      data: ['', Validators.required],
      quilometragem: ['', Validators.required],
      servico: ['', Validators.required],
      observacoes: ['']
    });
  }

  ngOnInit() {
    this.veiculoId = this.route.snapshot.paramMap.get('veiculoId')!;
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.manutencaoId = Number(id);
      this.manutencaoService.getById(this.manutencaoId).subscribe(data => {
        this.form.patchValue(data);
      });
    }
  }

  onSubmit() {
    if (this.form.invalid) return;

    const data: Manutencao = {
      ...this.form.value,
      veiculoId: this.veiculoId
    };

    if (this.isEdit) {
      data.id = this.manutencaoId;
    }

    const request = this.isEdit
      ? this.manutencaoService.update(this.manutencaoId, data)
      : this.manutencaoService.create(data);

    request.subscribe(() => {
      this.router.navigate(['/manutencoes', this.veiculoId]);
    });
  }
}
