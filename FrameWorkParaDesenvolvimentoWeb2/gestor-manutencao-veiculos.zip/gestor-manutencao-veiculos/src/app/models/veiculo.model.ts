export interface Veiculo {
  id: string;
  usuarioId: string;
  placa: string;
  modelo: string;
  marca: string;
  ano: number;
  combustivel: string;
}
